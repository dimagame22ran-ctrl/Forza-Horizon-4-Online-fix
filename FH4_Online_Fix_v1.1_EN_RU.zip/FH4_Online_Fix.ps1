﻿# FH4 Online Fix v1.1 (Steam Edition)
# Community-made Windows network diagnostic helper. Does not modify game files.
# Requires Windows PowerShell 5.1 on Windows 10 or 11.
param(
    [switch]$DoFix,
    [switch]$DoRestore,
    [ValidateSet('en', 'ru')][string]$Language
)

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$script:Version = '1.1'
$script:MainForm = $null
$script:LogControl = $null
$script:StatusLabel = $null
$script:StatusKey = 'status.ready'
$script:StatusValues = @()
$script:StatusState = 'normal'
$script:SessionLog = New-Object 'System.Collections.Generic.List[object]'
$script:ServiceDefs = @(
    @{ Name = 'iphlpsvc';       Label = 'IP Helper';               Target = 'Automatic' },
    @{ Name = 'XblAuthManager'; Label = 'Xbox Live Auth Manager'; Target = 'Manual' },
    @{ Name = 'XboxNetApiSvc';  Label = 'Xbox Live Networking';   Target = 'Manual' }
)
$script:DataPath = Join-Path $env:ProgramData 'FH4OnlineFix'
$script:BackupFile = Join-Path $script:DataPath 'service-backup.json'
$script:PrefPath = Join-Path $env:LOCALAPPDATA 'FH4OnlineFix\settings.json'

# Default is English on the first launch. Keep a user's subsequent selection.
if (-not $Language -and (Test-Path -LiteralPath $script:PrefPath)) {
    try {
        $prefs = Get-Content -LiteralPath $script:PrefPath -Raw -Encoding UTF8 -ErrorAction Stop | ConvertFrom-Json -ErrorAction Stop
        if ($prefs.Language -in @('en', 'ru')) { $Language = $prefs.Language }
    } catch { }
}
if (-not $Language) { $Language = 'en' }
$script:Lang = $Language

$script:I18n = @{
    en = @{
        'window'            = 'FH4 Online Fix v1.1 - Steam'
        'tagline'           = 'NETWORK REPAIR  |  STEAM EDITION  |  v1.1'
        'description'       = 'No game modifications. Diagnostics and reversible Windows repairs only.'
        'language'          = 'Language'
        'scan'              = 'CHECK'
        'fix'               = 'REPAIR'
        'undo'              = 'RESTORE'
        'help'              = 'NEXT STEPS'
        'report'            = 'REPORT'
        'footer'            = 'FH4 Steam  |  Installed game and a signed-in Microsoft/Xbox account required'
        'status.ready'      = 'Ready to check your connection'
        'status.scanning'   = 'Running diagnostics...'
        'status.issues'     = 'Check complete: {0} possible issue(s)'
        'status.clean'      = 'No critical local issues were found'
        'status.noBackup'   = 'Repair cancelled: backup could not be saved'
        'status.fixed'      = 'Repair finished - test multiplayer in the game'
        'status.noChanges'  = 'No saved changes to restore'
        'status.restored'   = 'Original service startup settings restored'
        'status.partial'    = 'Some settings could not be restored'
        'status.undoError'  = 'Restore failed'
        'app.started'       = 'FH4 Online Fix v1.1 started.'
        'app.tip'           = 'Click CHECK first. Repairing Windows settings may require administrator permission.'
        'language.changed' = 'Interface language changed to English.'
        'svc.readError'     = 'Could not read service {0}: {1}'
        'teredo.cmdFailed'  = 'Teredo command did not complete.'
        'teredo.readFailed' = 'Could not obtain Teredo status.'
        'scan.start'        = 'Checking Windows and Xbox Live services (Steam version of FH4).'
        'scan.missing'      = '{0}: service was not found. This is not always a problem on every Windows installation.'
        'scan.disabled'     = '{0}: DISABLED - a possible cause of connection issues.'
        'scan.running'      = '{0}: running (startup: {1}).'
        'scan.stopped'      = '{0}: stopped (startup: {1}).'
        'scan.demand'       = '{0}: waiting for a trigger (startup: {1}); this may be normal for Xbox services.'
        'scan.firewallOK'   = 'Windows Firewall service is running.'
        'scan.firewallBad'  = 'Windows Firewall service is not running. Check the settings manually.'
        'scan.dnsOK'        = 'DNS {0}: name resolves (this does not test the game servers).'
        'scan.dnsBad'       = 'DNS {0}: no address returned.'
        'scan.dnsError'     = 'DNS {0}: name resolution failed.'
        'scan.teredo'       = 'Teredo state (diagnostics only; settings are NOT changed):'
        'scan.raw'          = '  {0}'
        'scan.teredoNote'   = 'Note: Teredo status alone does not identify the cause of an FH4 connection error.'
        'scan.vpn'          = 'Active VPN/virtual adapter found: a conflict is possible. Check it manually.'
        'scan.finished'     = 'Check finished. Repair cannot guarantee a connection when the server, NAT or ISP is the cause.'
        'fix.needAdmin'     = 'Repair requires administrator permission.'
        'fix.closeGame'     = 'Close Forza Horizon 4 before repairing. The tool will not force-quit the game.'
        'fix.start'         = 'Starting repair. Steam and FH4 game files will not be modified.'
        'fix.backupFailed'  = 'Could not save a backup: {0}'
        'fix.backupOK'      = 'A backup of service startup settings has been saved for restoration.'
        'fix.backupBroken'  = 'The existing backup file is damaged. Repair cancelled to preserve the original settings.'
        'fix.enabled'       = '{0}: startup set to {1}.'
        'fix.enableFailed'  = 'Could not enable {0}: {1}'
        'fix.started'       = '{0}: service started.'
        'fix.startFailed'   = '{0}: service could not start now; Xbox services may start on demand.'
        'fix.dnsFlushed'    = 'Windows DNS cache flushed.'
        'fix.dnsBad'        = 'Could not flush the DNS cache.'
        'fix.finished'      = 'Done. Restart Steam and FH4. If needed, sign out of and back into the Microsoft account in FH4.'
        'undo.needAdmin'    = 'Restoring settings requires administrator permission.'
        'undo.noBackup'     = 'No backup found. There are no saved changes to restore.'
        'undo.badFormat'    = 'Unknown backup file format.'
        'undo.serviceOK'    = '{0}: startup setting restored to {1}.'
        'undo.serviceBad'   = 'Could not restore {0}.'
        'undo.complete'     = 'Settings restored. Services have not been forcibly stopped.'
        'undo.partial'      = 'Partial restore. The backup is retained so you can try again.'
        'undo.failed'       = 'Restore error: {0}'
        'admin.verb.fix'    = 'repair Xbox service settings'
        'admin.verb.undo'   = 'restore service settings'
        'admin.confirm'     = 'Administrator permission is needed to {0}. Open a separate window with a Windows permission prompt?'
        'admin.launched'    = 'Administrator window launched.'
        'admin.cancelled'   = 'Administrator permission was cancelled or the window could not be opened: {0}'
        'report.filter'     = 'Text file (*.txt)|*.txt'
        'report.title'      = 'Save diagnostic report'
        'report.saved'      = 'Report saved.'
        'report.failed'     = 'Could not save report: {0}'
        'help.title'        = 'Troubleshooting steps'
        'help.body'         = @'
If the problem continues:

1. Close FH4, open it again, then sign out of your Microsoft account in the game's startup menu and sign back in.
2. In Steam: game Properties > Installed Files > Verify integrity of game files.
3. If you use a VPN or virtual tunnel, test the connection without it.
4. Restart the PC and router. Test multiplayer on another network to isolate ISP/NAT problems.
5. Save a report and contact Forza Support if the error remains.

Do NOT disable your firewall, enable DMZ or blindly change Teredo. Some failures are caused by ISP CGNAT, NAT or game servers.
'@
    }
    ru = @{
        'window'            = 'FH4 Online Fix v1.1 - Steam'
        'tagline'           = 'ИСПРАВЛЕНИЕ СЕТИ  |  STEAM EDITION  |  v1.1'
        'description'       = 'Без изменения игры. Диагностика и обратимые исправления Windows.'
        'language'          = 'Язык'
        'scan'              = 'ПРОВЕРИТЬ'
        'fix'               = 'ИСПРАВИТЬ'
        'undo'              = 'ОТКАТ'
        'help'              = 'ЧТО ЕЩЁ?'
        'report'            = 'ОТЧЁТ'
        'footer'            = 'FH4 Steam  |  Нужны установленная игра и вход в аккаунт Microsoft/Xbox'
        'status.ready'      = 'Готов к проверке подключения'
        'status.scanning'   = 'Идёт диагностика...'
        'status.issues'     = 'Проверка завершена: возможных проблем — {0}'
        'status.clean'      = 'Критических локальных проблем не обнаружено'
        'status.noBackup'   = 'Исправление отменено: не удалось сохранить резервную копию'
        'status.fixed'      = 'Исправление завершено — проверь онлайн в игре'
        'status.noChanges'  = 'Нет сохранённых изменений для отката'
        'status.restored'   = 'Исходные настройки запуска служб восстановлены'
        'status.partial'    = 'Некоторые настройки восстановить не удалось'
        'status.undoError'  = 'Ошибка отката'
        'app.started'       = 'FH4 Online Fix v1.1 запущен.'
        'app.tip'           = 'Сначала нажми «ПРОВЕРИТЬ». Исправление может потребовать прав администратора.'
        'language.changed' = 'Язык интерфейса изменён на русский.'
        'svc.readError'     = 'Не удалось прочитать службу {0}: {1}'
        'teredo.cmdFailed'  = 'Команда Teredo не выполнена.'
        'teredo.readFailed' = 'Не удалось получить статус Teredo.'
        'scan.start'        = 'Проверка Windows и служб Xbox Live (Steam-версия FH4).'
        'scan.missing'      = '{0}: служба не найдена. Это не всегда ошибка (зависит от Windows).'
        'scan.disabled'     = '{0}: ОТКЛЮЧЕНА — возможная причина проблемы.'
        'scan.running'      = '{0}: работает (запуск: {1}).'
        'scan.stopped'      = '{0}: остановлена (запуск: {1}).'
        'scan.demand'       = '{0}: ждёт события (запуск: {1}); для Xbox это может быть нормально.'
        'scan.firewallOK'   = 'Служба брандмауэра Windows работает.'
        'scan.firewallBad'  = 'Служба брандмауэра Windows не запущена. Проверь настройки вручную.'
        'scan.dnsOK'        = 'DNS {0}: имя разрешается (это не проверка серверов игры).'
        'scan.dnsBad'       = 'DNS {0}: не получен IP-адрес.'
        'scan.dnsError'     = 'DNS {0}: ошибка разрешения имени.'
        'scan.teredo'       = 'Teredo (только диагностика, настройки НЕ меняются):'
        'scan.raw'          = '  {0}'
        'scan.teredoNote'   = 'Важно: состояние Teredo само по себе не доказывает причину ошибки FH4.'
        'scan.vpn'          = 'Найден активный VPN/виртуальный адаптер: возможен конфликт. Проверь вручную.'
        'scan.finished'     = 'Проверка завершена. Исправление не гарантирует подключения при проблемах сервера, NAT или провайдера.'
        'fix.needAdmin'     = 'Для исправления нужны права администратора.'
        'fix.closeGame'     = 'Сначала закрой Forza Horizon 4. Программа не будет принудительно завершать игру.'
        'fix.start'         = 'Начало исправления. Файлы Steam и FH4 не затрагиваются.'
        'fix.backupFailed'  = 'Не удалось сохранить резервную копию: {0}'
        'fix.backupOK'      = 'Резервная копия настроек запуска служб сохранена для отката.'
        'fix.backupBroken'  = 'Старая копия повреждена. Исправление отменено, чтобы сохранить исходные настройки.'
        'fix.enabled'       = '{0}: тип запуска изменён на {1}.'
        'fix.enableFailed'  = 'Не получилось включить {0}: {1}'
        'fix.started'       = '{0}: служба запущена.'
        'fix.startFailed'   = '{0}: служба сейчас не запустилась; службы Xbox могут запускаться по запросу.'
        'fix.dnsFlushed'    = 'Кэш DNS Windows очищен.'
        'fix.dnsBad'        = 'Не удалось очистить кэш DNS.'
        'fix.finished'      = 'Готово. Перезапусти Steam и FH4. При необходимости заново войди в Microsoft-аккаунт в FH4.'
        'undo.needAdmin'    = 'Для отката нужны права администратора.'
        'undo.noBackup'     = 'Резервная копия не найдена. Для отката нет сохранённых изменений.'
        'undo.badFormat'    = 'Неизвестный формат резервной копии.'
        'undo.serviceOK'    = '{0}: тип запуска восстановлен на {1}.'
        'undo.serviceBad'   = 'Не удалось восстановить {0}.'
        'undo.complete'     = 'Настройки восстановлены. Службы принудительно не останавливались.'
        'undo.partial'      = 'Откат частичный; резервная копия сохранена для повторной попытки.'
        'undo.failed'       = 'Ошибка отката: {0}'
        'admin.verb.fix'    = 'исправить настройки служб Xbox'
        'admin.verb.undo'   = 'восстановить настройки служб'
        'admin.confirm'     = 'Чтобы {0}, нужны права администратора. Открыть отдельное окно с запросом Windows?'
        'admin.launched'    = 'Открыто окно с правами администратора.'
        'admin.cancelled'   = 'Запрос прав администратора отменён или не удался: {0}'
        'report.filter'     = 'Текстовый файл (*.txt)|*.txt'
        'report.title'      = 'Сохранить отчёт диагностики'
        'report.saved'      = 'Отчёт сохранён.'
        'report.failed'     = 'Не удалось сохранить отчёт: {0}'
        'help.title'        = 'Что делать дальше'
        'help.body'         = @'
Если проблема осталась:

1. Закрой FH4, открой снова, выйди из Microsoft-аккаунта в стартовом меню игры и войди заново.
2. В Steam: Свойства игры > Установленные файлы > Проверить целостность.
3. Если используется VPN или виртуальный туннель, проверь подключение без него.
4. Перезагрузи роутер и ПК. Проверь онлайн через другую сеть, чтобы исключить проблемы провайдера/NAT.
5. Сохрани отчёт и обратись в поддержку Forza, если ошибка осталась.

Не отключай брандмауэр, не включай DMZ и не меняй Teredo вслепую. Причиной могут быть NAT/CGNAT провайдера или серверы игры.
'@
    }
}

function T {
    param([string]$Key, [object[]]$Values = @())
    $value = $script:I18n[$script:Lang][$Key]
    if ($null -eq $value) { $value = $script:I18n['en'][$Key] }
    if ($null -eq $value) { return $Key }
    if ($Values.Count -gt 0) { return [string]::Format([string]$value, [object[]]$Values) }
    return [string]$value
}

function Save-Language {
    try {
        $dir = Split-Path -Parent $script:PrefPath
        New-Item -ItemType Directory -Path $dir -Force -ErrorAction Stop | Out-Null
        [pscustomobject]@{ Language = $script:Lang } |
            ConvertTo-Json | Set-Content -LiteralPath $script:PrefPath -Encoding UTF8 -ErrorAction Stop
    } catch {
        # Language switching still works without permission to save preferences.
    }
}

function Append-LogEntry {
    param([object]$Entry)
    if (-not $script:LogControl -or $script:LogControl.IsDisposed) { return }
    $color = switch ($Entry.Level) {
        'OK'    { [System.Drawing.Color]::FromArgb(114, 219, 160) }
        'WARN'  { [System.Drawing.Color]::FromArgb(255, 199, 102) }
        'ERROR' { [System.Drawing.Color]::FromArgb(255, 132, 132) }
        default { [System.Drawing.Color]::FromArgb(213, 225, 241) }
    }
    $line = '[{0}] [{1}] {2}' -f $Entry.Time, $Entry.Level, (T -Key $Entry.Key -Values $Entry.Values)
    $script:LogControl.SelectionStart = $script:LogControl.TextLength
    $script:LogControl.SelectionLength = 0
    $script:LogControl.SelectionColor = $color
    $script:LogControl.AppendText($line + [Environment]::NewLine)
}

function Write-Log {
    param([string]$Key, [ValidateSet('INFO','OK','WARN','ERROR')][string]$Level = 'INFO',
          [object[]]$Values = @())
    $entry = [pscustomobject]@{
        Time   = (Get-Date -Format 'HH:mm:ss')
        Level  = $Level
        Key    = $Key
        Values = @($Values)
    }
    $script:SessionLog.Add($entry)
    Append-LogEntry $entry
    if ($script:LogControl -and -not $script:LogControl.IsDisposed) {
        $script:LogControl.ScrollToCaret()
        [System.Windows.Forms.Application]::DoEvents()
    }
}

function Render-Log {
    if (-not $script:LogControl -or $script:LogControl.IsDisposed) { return }
    $script:LogControl.Clear()
    foreach ($entry in $script:SessionLog) { Append-LogEntry $entry }
    $script:LogControl.ScrollToCaret()
}

function Refresh-Status {
    if (-not $script:StatusLabel) { return }
    $script:StatusLabel.Text = T -Key $script:StatusKey -Values $script:StatusValues
    $script:StatusLabel.ForeColor = switch ($script:StatusState) {
        'good' { [System.Drawing.Color]::FromArgb(114, 219, 160) }
        'warn' { [System.Drawing.Color]::FromArgb(255, 199, 102) }
        'bad'  { [System.Drawing.Color]::FromArgb(255, 132, 132) }
        default { [System.Drawing.Color]::FromArgb(189, 202, 220) }
    }
}

function Set-Status {
    param([string]$Key, [string]$State = 'normal', [object[]]$Values = @())
    $script:StatusKey = $Key
    $script:StatusState = $State
    $script:StatusValues = @($Values)
    Refresh-Status
}

function Test-IsAdmin {
    $identity = [Security.Principal.WindowsIdentity]::GetCurrent()
    $principal = New-Object Security.Principal.WindowsPrincipal($identity)
    return $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Get-ServiceInfo {
    param([string]$ServiceName)
    try {
        return Get-CimInstance -ClassName Win32_Service -Filter ("Name='{0}'" -f $ServiceName) -ErrorAction Stop
    } catch {
        Write-Log 'svc.readError' 'WARN' @($ServiceName, $_.Exception.Message)
        return $null
    }
}

function Get-TeredoText {
    try {
        $output = (& "$env:WINDIR\System32\netsh.exe" interface teredo show state 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) { return (T 'teredo.cmdFailed') }
        return $output
    } catch {
        return (T 'teredo.readFailed')
    }
}

function Invoke-Scan {
    Set-Status 'status.scanning'
    Write-Log 'scan.start'
    $issues = 0
    foreach ($entry in $script:ServiceDefs) {
        $svc = Get-ServiceInfo $entry.Name
        if (-not $svc) {
            Write-Log 'scan.missing' 'WARN' @($entry.Label)
            continue
        }
        if ($svc.StartMode -eq 'Disabled') {
            Write-Log 'scan.disabled' 'WARN' @($entry.Label)
            $issues++
        } elseif ($svc.State -eq 'Running') {
            Write-Log 'scan.running' 'OK' @($entry.Label, $svc.StartMode)
        } elseif ($entry.Name -eq 'iphlpsvc') {
            Write-Log 'scan.stopped' 'WARN' @($entry.Label, $svc.StartMode)
            $issues++
        } else {
            Write-Log 'scan.demand' 'INFO' @($entry.Label, $svc.StartMode)
        }
    }

    $firewall = Get-ServiceInfo 'MpsSvc'
    if ($firewall) {
        if ($firewall.State -eq 'Running') { Write-Log 'scan.firewallOK' 'OK' }
        else { Write-Log 'scan.firewallBad' 'WARN' }
    }

    foreach ($hostname in @('login.live.com', 'steamcommunity.com')) {
        try {
            $addresses = [System.Net.Dns]::GetHostAddresses($hostname)
            if ($addresses.Count -gt 0) { Write-Log 'scan.dnsOK' 'OK' @($hostname) }
            else { Write-Log 'scan.dnsBad' 'WARN' @($hostname); $issues++ }
        } catch {
            Write-Log 'scan.dnsError' 'WARN' @($hostname)
            $issues++
        }
    }

    $teredo = Get-TeredoText
    Write-Log 'scan.teredo'
    foreach ($line in ($teredo -split "`r?`n")) {
        if (-not [string]::IsNullOrWhiteSpace($line)) { Write-Log 'scan.raw' 'INFO' @($line.Trim()) }
    }
    Write-Log 'scan.teredoNote'

    try {
        $adapters = @(Get-NetAdapter -ErrorAction Stop | Where-Object {
            $_.Status -eq 'Up' -and
            ($_.InterfaceDescription -match '(?i)wireguard|openvpn|tap-windows|tunnelbear|nordlynx|tailscale|zerotier|hamachi|radmin vpn')
        })
        if ($adapters.Count -gt 0) { Write-Log 'scan.vpn' 'WARN' }
    } catch { }

    Write-Log 'scan.finished'
    if ($issues -gt 0) { Set-Status 'status.issues' 'warn' @($issues) }
    else { Set-Status 'status.clean' 'good' }
}

function Save-Backup {
    param([object[]]$NewEntries)
    if ($NewEntries.Count -eq 0) { return }
    New-Item -ItemType Directory -Path $script:DataPath -Force -ErrorAction Stop | Out-Null
    $entries = @()
    if (Test-Path -LiteralPath $script:BackupFile) {
        try {
            $previous = Get-Content -LiteralPath $script:BackupFile -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
            $entries = @($previous.Services | Where-Object { $null -ne $_ })
        } catch {
            throw (T 'fix.backupBroken')
        }
    }
    foreach ($newEntry in $NewEntries) {
        if (@($entries | Where-Object { $_.Name -eq $newEntry.Name }).Count -eq 0) {
            $entries += $newEntry
        }
    }
    $data = [pscustomobject]@{
        Format = 1
        SavedAt = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
        Services = @($entries)
    }
    $temp = $script:BackupFile + '.tmp'
    $data | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $temp -Encoding UTF8 -ErrorAction Stop
    Move-Item -LiteralPath $temp -Destination $script:BackupFile -Force -ErrorAction Stop
    Write-Log 'fix.backupOK' 'OK'
}

function Invoke-Repair {
    if (-not (Test-IsAdmin)) { Write-Log 'fix.needAdmin' 'ERROR'; return }
    if (Get-Process -Name 'ForzaHorizon4' -ErrorAction SilentlyContinue) {
        [System.Windows.Forms.MessageBox]::Show((T 'fix.closeGame'), 'FH4 Online Fix', 'OK', 'Information') | Out-Null
        return
    }
    Write-Log 'fix.start'
    $disabled = @()
    foreach ($entry in $script:ServiceDefs) {
        $svc = Get-ServiceInfo $entry.Name
        if ($svc -and $svc.StartMode -eq 'Disabled') {
            $disabled += [pscustomobject]@{ Name = $entry.Name; StartMode = $svc.StartMode }
        }
    }
    try { Save-Backup -NewEntries $disabled }
    catch {
        Write-Log 'fix.backupFailed' 'ERROR' @($_.Exception.Message)
        Set-Status 'status.noBackup' 'bad'
        return
    }

    foreach ($entry in $script:ServiceDefs) {
        $svc = Get-ServiceInfo $entry.Name
        if (-not $svc) { continue }
        if ($svc.StartMode -eq 'Disabled') {
            try {
                Set-Service -Name $entry.Name -StartupType $entry.Target -ErrorAction Stop
                Write-Log 'fix.enabled' 'OK' @($entry.Label, $entry.Target)
            } catch {
                Write-Log 'fix.enableFailed' 'ERROR' @($entry.Label, $_.Exception.Message)
                continue
            }
        }
        if ($svc.State -ne 'Running') {
            try {
                Start-Service -Name $entry.Name -ErrorAction Stop
                Write-Log 'fix.started' 'OK' @($entry.Label)
            } catch {
                Write-Log 'fix.startFailed' 'WARN' @($entry.Label)
            }
        }
    }
    try {
        & "$env:WINDIR\System32\ipconfig.exe" /flushdns | Out-Null
        if ($LASTEXITCODE -eq 0) { Write-Log 'fix.dnsFlushed' 'OK' }
        else { Write-Log 'fix.dnsBad' 'WARN' }
    } catch { Write-Log 'fix.dnsBad' 'WARN' }

    Write-Log 'fix.finished' 'OK'
    Set-Status 'status.fixed' 'good'
}

function Invoke-Restore {
    if (-not (Test-IsAdmin)) { Write-Log 'undo.needAdmin' 'ERROR'; return }
    if (-not (Test-Path -LiteralPath $script:BackupFile)) {
        Write-Log 'undo.noBackup' 'WARN'
        Set-Status 'status.noChanges'
        return
    }
    try {
        $backup = Get-Content -LiteralPath $script:BackupFile -Raw -Encoding UTF8 | ConvertFrom-Json -ErrorAction Stop
        if ($backup.Format -ne 1) { throw (T 'undo.badFormat') }
        $failed = 0
        foreach ($item in @($backup.Services)) {
            if (-not $item -or $item.Name -notin @('iphlpsvc', 'XblAuthManager', 'XboxNetApiSvc')) { continue }
            if ($item.StartMode -notin @('Auto', 'Manual', 'Disabled')) { continue }
            if (-not (Get-ServiceInfo $item.Name)) { continue }
            try {
                $setting = switch ($item.StartMode) {
                    'Auto'     { 'Automatic' }
                    'Manual'   { 'Manual' }
                    'Disabled' { 'Disabled' }
                }
                Set-Service -Name $item.Name -StartupType $setting -ErrorAction Stop
                Write-Log 'undo.serviceOK' 'OK' @($item.Name, $setting)
            } catch {
                $failed++
                Write-Log 'undo.serviceBad' 'ERROR' @($item.Name)
            }
        }
        if ($failed -eq 0) {
            Remove-Item -LiteralPath $script:BackupFile -Force -ErrorAction Stop
            Write-Log 'undo.complete' 'OK'
            Set-Status 'status.restored' 'good'
        } else {
            Write-Log 'undo.partial' 'WARN'
            Set-Status 'status.partial' 'warn'
        }
    } catch {
        Write-Log 'undo.failed' 'ERROR' @($_.Exception.Message)
        Set-Status 'status.undoError' 'bad'
    }
}

function Request-Action {
    param([ValidateSet('Fix', 'Restore')][string]$Mode)
    if (Test-IsAdmin) {
        if ($Mode -eq 'Fix') { Invoke-Repair } else { Invoke-Restore }
        return
    }
    $verb = if ($Mode -eq 'Fix') { T 'admin.verb.fix' } else { T 'admin.verb.undo' }
    $answer = [System.Windows.Forms.MessageBox]::Show(
        (T 'admin.confirm' @($verb)), 'FH4 Online Fix', 'YesNo', 'Question')
    if ($answer -ne [System.Windows.Forms.DialogResult]::Yes) { return }
    $modeArg = if ($Mode -eq 'Fix') { '-DoFix' } else { '-DoRestore' }
    try {
        $psPath = Join-Path $env:WINDIR 'System32\WindowsPowerShell\v1.0\powershell.exe'
        $arguments = '-NoProfile -ExecutionPolicy Bypass -STA -File "' + $PSCommandPath + '" ' + $modeArg + ' -Language ' + $script:Lang
        Start-Process -FilePath $psPath -ArgumentList $arguments -Verb RunAs -ErrorAction Stop | Out-Null
        Write-Log 'admin.launched'
        $script:MainForm.Close()
    } catch {
        Write-Log 'admin.cancelled' 'WARN' @($_.Exception.Message)
    }
}

function Export-Report {
    $dialog = New-Object System.Windows.Forms.SaveFileDialog
    $dialog.Filter = T 'report.filter'
    $dialog.FileName = 'FH4_Network_Report.txt'
    $dialog.Title = T 'report.title'
    if ($dialog.ShowDialog() -ne [System.Windows.Forms.DialogResult]::OK) { return }
    try {
        @($script:SessionLog | ForEach-Object {
            '[{0}] [{1}] {2}' -f $_.Time, $_.Level, (T -Key $_.Key -Values $_.Values)
        }) | Out-File -FilePath $dialog.FileName -Encoding UTF8 -ErrorAction Stop
        Write-Log 'report.saved' 'OK'
    } catch {
        Write-Log 'report.failed' 'ERROR' @($_.Exception.Message)
    }
}

function Add-Label {
    param([System.Windows.Forms.Control]$Parent, [string]$Caption, [int]$X, [int]$Y,
          [int]$Width, [int]$Height, [int]$Size, [System.Drawing.Color]$Color, [bool]$Bold = $false)
    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Caption
    $label.Location = New-Object System.Drawing.Point($X, $Y)
    $label.Size = New-Object System.Drawing.Size($Width, $Height)
    $style = if ($Bold) { [System.Drawing.FontStyle]::Bold } else { [System.Drawing.FontStyle]::Regular }
    $label.Font = New-Object System.Drawing.Font('Segoe UI', $Size, $style)
    $label.ForeColor = $Color
    $Parent.Controls.Add($label)
    return $label
}

function Add-Button {
    param([string]$Caption, [int]$X, [int]$Width, [System.Drawing.Color]$Fill, [System.Drawing.Color]$TextColor)
    $button = New-Object System.Windows.Forms.Button
    $button.Text = $Caption
    $button.Location = New-Object System.Drawing.Point($X, 184)
    $button.Size = New-Object System.Drawing.Size($Width, 44)
    $button.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
    $button.FlatAppearance.BorderSize = 0
    $button.BackColor = $Fill
    $button.ForeColor = $TextColor
    $button.Font = New-Object System.Drawing.Font('Segoe UI Semibold', 10)
    $button.Cursor = [System.Windows.Forms.Cursors]::Hand
    $script:MainForm.Controls.Add($button)
    return $button
}

# Main window. Language picker is deliberately visible in the top-right corner.
$form = New-Object System.Windows.Forms.Form
$form.Size = New-Object System.Drawing.Size(790, 640)
$form.MinimumSize = $form.Size
$form.MaximumSize = $form.Size
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.BackColor = [System.Drawing.Color]::FromArgb(17, 23, 34)
$form.ForeColor = [System.Drawing.Color]::White
$form.Font = New-Object System.Drawing.Font('Segoe UI', 10)
$form.AutoScaleMode = [System.Windows.Forms.AutoScaleMode]::None
$script:MainForm = $form

$banner = New-Object System.Windows.Forms.Panel
$banner.Location = New-Object System.Drawing.Point(0, 0)
$banner.Size = New-Object System.Drawing.Size(790, 161)
$banner.BackColor = [System.Drawing.Color]::FromArgb(26, 37, 56)
$form.Controls.Add($banner)

$blue = [System.Drawing.Color]::FromArgb(104, 166, 255)
$white = [System.Drawing.Color]::FromArgb(239, 245, 255)
$muted = [System.Drawing.Color]::FromArgb(168, 185, 208)
Add-Label $banner 'FH4  /  ONLINE FIX' 27 22 480 36 20 $white $true | Out-Null
$lblLanguage = Add-Label $banner '' 560 18 200 23 9 $muted
$picker = New-Object System.Windows.Forms.ComboBox
$picker.Location = New-Object System.Drawing.Point(560, 45)
$picker.Size = New-Object System.Drawing.Size(200, 30)
$picker.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDownList
$picker.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$picker.BackColor = [System.Drawing.Color]::FromArgb(39, 53, 75)
$picker.ForeColor = $white
$picker.Font = New-Object System.Drawing.Font('Segoe UI', 10)
[void]$picker.Items.Add('English')
[void]$picker.Items.Add('Русский')
$picker.SelectedIndex = if ($script:Lang -eq 'ru') { 1 } else { 0 }
$banner.Controls.Add($picker)

$lblTagline = Add-Label $banner '' 28 77 730 25 10 $blue $true
$lblDescription = Add-Label $banner '' 28 111 735 23 9 $muted

$btnScan = Add-Button '' 28 150 $blue ([System.Drawing.Color]::FromArgb(11, 24, 40))
$btnFix = Add-Button '' 188 145 ([System.Drawing.Color]::FromArgb(47, 126, 96)) $white
$btnUndo = Add-Button '' 343 110 ([System.Drawing.Color]::FromArgb(59, 70, 90)) $white
$btnHelp = Add-Button '' 463 126 ([System.Drawing.Color]::FromArgb(59, 70, 90)) $white
$btnSave = Add-Button '' 599 145 ([System.Drawing.Color]::FromArgb(59, 70, 90)) $white

$script:StatusLabel = Add-Label $form '' 28 246 735 31 11 $muted $true
$logPanel = New-Object System.Windows.Forms.Panel
$logPanel.Location = New-Object System.Drawing.Point(26, 292)
$logPanel.Size = New-Object System.Drawing.Size(738, 248)
$logPanel.BackColor = [System.Drawing.Color]::FromArgb(12, 17, 25)
$form.Controls.Add($logPanel)

$log = New-Object System.Windows.Forms.RichTextBox
$log.Dock = [System.Windows.Forms.DockStyle]::Fill
$log.BorderStyle = [System.Windows.Forms.BorderStyle]::None
$log.BackColor = $logPanel.BackColor
$log.ForeColor = $white
$log.Font = New-Object System.Drawing.Font('Consolas', 9)
$log.ReadOnly = $true
$log.WordWrap = $true
$log.ScrollBars = [System.Windows.Forms.RichTextBoxScrollBars]::Vertical
$log.DetectUrls = $false
$logPanel.Padding = New-Object System.Windows.Forms.Padding(12)
$logPanel.Controls.Add($log)
$script:LogControl = $log

$lblFooter = Add-Label $form '' 28 554 728 24 9 $muted

function Update-Language {
    $script:MainForm.Text = T 'window'
    $lblLanguage.Text = T 'language'
    $lblTagline.Text = T 'tagline'
    $lblDescription.Text = T 'description'
    $btnScan.Text = T 'scan'
    $btnFix.Text = T 'fix'
    $btnUndo.Text = T 'undo'
    $btnHelp.Text = T 'help'
    $btnSave.Text = T 'report'
    $lblFooter.Text = T 'footer'
    Refresh-Status
    Render-Log
}

Update-Language
$picker.Add_SelectedIndexChanged({
    $selected = if ($picker.SelectedIndex -eq 1) { 'ru' } else { 'en' }
    if ($script:Lang -eq $selected) { return }
    $script:Lang = $selected
    Save-Language
    Update-Language
    Write-Log 'language.changed' 'OK'
})

$btnScan.Add_Click({ Invoke-Scan })
$btnFix.Add_Click({ Request-Action 'Fix' })
$btnUndo.Add_Click({ Request-Action 'Restore' })
$btnHelp.Add_Click({
    [System.Windows.Forms.MessageBox]::Show((T 'help.body'), (T 'help.title'), 'OK', 'Information') | Out-Null
})
$btnSave.Add_Click({ Export-Report })
$form.Add_Shown({
    Write-Log 'app.started' 'OK'
    Write-Log 'app.tip'
    if ($DoFix) { Invoke-Repair; Invoke-Scan }
    elseif ($DoRestore) { Invoke-Restore; Invoke-Scan }
})

[void]$form.ShowDialog()
$form.Dispose()
