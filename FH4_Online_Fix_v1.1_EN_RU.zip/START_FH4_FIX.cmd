@echo off
setlocal
cd /d "%~dp0"
set "PS=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS%" (
 echo Windows PowerShell 5.1 not found.
 pause
 exit /b 1
)
"%PS%" -NoProfile -STA -ExecutionPolicy Bypass -File "%~dp0FH4_Online_Fix.ps1"
if errorlevel 1 (
 echo FH4 Online Fix could not start. See the README file.
 pause
)
endlocal
